OSmars PC GUI: Use the graphical environment to create folders, open files and launch a browser.
