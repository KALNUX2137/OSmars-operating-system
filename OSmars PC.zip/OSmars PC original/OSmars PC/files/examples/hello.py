#!/usr/bin/env python3
"""
Sample OSmars PC Program
"""

def main():
    print("🚀 Welcome to OSmars PC!")
    print("This file is located in the examples directory")
    print("You can run it with: boot hello.py")

    name = input("What's your name? ")
    print(f"Nice to meet you, {name}!")

if __name__ == "__main__":
    main()
