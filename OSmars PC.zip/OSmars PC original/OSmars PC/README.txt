OSmars PC - Enhanced Terminal System with PySide6 GUI
======================================================

Welcome to OSmars PC! This is an advanced terminal system with PySide6 desktop environment.

Basic commands:
- help          - Show help
- ls -l         - List files with details
- cd <dir>      - Change directory
- edit <file>   - Edit file (nano-like editor)
- boot <file>   - Run Python file
- find <pattern>- Search files
- tree          - Directory structure
- bootsys       - Launch PySide6 GUI desktop

Advanced features:
- Command history (history)
- Aliases (alias name=command)
- Configuration (config)
- Syntax coloring
- Auto-save
- PySide6 desktop environment with embedded browser
- File manager, notepad, calculator apps

Package Management:
- sudo pacman -S pyside6   - Install PySide6 for GUI support

Examples are located in files/examples/
Use 'bootsys' to launch the graphical desktop environment!

The GUI system is generated as boot/desktop/gui_system.py
